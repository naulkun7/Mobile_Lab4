package com.example.reply.ui.utils

enum class ReplyNavigationType {
}